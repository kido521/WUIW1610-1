/*
* @Author: Administrator
* @Date:   2017-08-31 18:15:24
* @Last Modified by:   Administrator
* @Last Modified time: 2017-08-31 21:10:50
*/
$(function(){
	var spot = $('.banner_box>.spot>li');
	var banner = $('.banner_box>.banner');
	spot.mouseenter(function () {
		var index = $(this).index();
		spot.css('background','#fff').eq(index).css('background','#c77c51');
		banner.css('opacity',0).eq(index).css('opacity',1);
	});

	var n = 0;
	function move(type = 'l'){
		if(type=='r'){
			n--;
			if(n<0){
				n=2;
			}
		}else{
			n++;
			if(n>2){
				n=0;
			}
		}
		banner.css('opacity',0).eq(n).css('opacity',1);
		spot.css('background','#fff').eq(n).css('background','#c77c51');
	}
	$('.banner_box>.btn>.btn_right').click(move);
	$('.banner_box>.btn>.btn_left').click(function(){
		move('r');
	});
	var t = setInterval(move, 2000);
	$('.banner_box').hover(
		function(){
			clearInterval(t);
		},
		function(){
			t = setInterval(move, 2000);
		}
	)

})