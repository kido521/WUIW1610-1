/*
* @Author: Administrator
* @Date:   2017-09-03 19:18:35
* @Last Modified by:   Administrator
* @Last Modified time: 2017-09-03 19:34:20
*/
$(function () {
	var images = $('.bag .right ul li');
	images.mouseenter(function(){
		$('.bag .right>img').attr('src',$(this).children().attr('src'))
		console.log($(this).attr('src'))
		images.removeClass('active').eq($(this).index()).addClass('active');
	});
})